#include <string>
#include "werewolf.h"
#include "player.h"
#include "map.h"
using namespace std;


Werewolf::Werewolf(int row, int col, Map *mp, Player *pc):
    NPC(row, col, mp, 'W', "Were-Wolf", 120, 120, 30, 5, 1, true, pc) {}

Werewolf::~Werewolf() {}
