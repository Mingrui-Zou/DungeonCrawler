#include <iostream>
#include <iomanip>
#include "map.h"
#include "cell.h"
#include "player.h"
#include "ork.h"
using namespace std;

Ork::Ork(int row, int col, Map *mp):
    Player(row, col, mp, 180, 180, 30, 25),
    goldCarry(false) {}

Ork::~Ork() {}

int Ork::takeTreasure(Cell *cll) {
    int amt = cll->getOccupant()->getVal();
    gold += amt/2;
    addScore(amt/2);
    if (goldCarry && amt%2) {
        gold++;
        addScore(1);
        goldCarry = false;
    } else {
        goldCarry = goldCarry || amt%2;
    }

    cll->clearOccupant(true);

    return amt;
}

string Ork::takePotion(Cell *cll) {
    string potName = cll->getOccupant()->use(this);
    cll->clearOccupant(true);
    return potName;
}

void Ork::playerInfo() {
    cout << setiosflags(ios::left);
    cout << "Race: Ork Gold: " << setw(WIDTH-26) << gold;
    cout << "Floor " << mp->getFloor() << endl;
    if (health<0) health=0;
    cout << "HP: " << health << endl;
    cout << "Atk: " << atk+atkBonus << endl;
    cout << "Def: " << def+defBonus << endl;
}
