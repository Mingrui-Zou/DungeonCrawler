#include <iostream>
#include <iomanip>
#include "map.h"
#include "cell.h"
#include "player.h"
#include "human.h"
using namespace std;

Human::Human(int row, int col, Map *mp):
    Player(row, col, mp, 140, 140, 20, 20), 
    scoreCarry(false) {}

Human::~Human() {}

string Human::takePotion(Cell *cll) {
    string potName = cll->getOccupant()->use(this);
    cll->clearOccupant(true);
    return potName;
}

void Human::addScore(int points) {
    score += points + points/2;
    if (scoreCarry && points%2) {
        score++;
        scoreCarry = false;
    } else {
        scoreCarry = scoreCarry || points%2;
    }
}

void Human::playerInfo() {
    cout << setiosflags(ios::left);
    cout << "Race: Human Gold: " << setw(WIDTH-28) << gold;
    cout << "Floor " << mp->getFloor() << endl;
    if (health<0) health=0;
    cout << "HP: " << health << endl;
    cout << "Atk: " << atk+atkBonus << endl;
    cout << "Def: " << def+defBonus << endl;
}
