#include <iostream>
#include <iomanip>
#include "map.h"
#include "cell.h"
#include "player.h"
#include "elf.h"
using namespace std;

Elf::Elf(int row, int col, Map *mp):
    Player(row, col, mp, 140, 140, 30, 10) {}

Elf::~Elf() {}

string Elf::takePotion(Cell *cll) {
    string potName = cll->getOccupant()->use(this);
    cll->clearOccupant(true);
    return potName;
}

void Elf::playerInfo() {
    cout << setiosflags(ios::left);
    cout << "Race: Elf Gold: " << setw(WIDTH-28) << gold;
    cout << "Floor " << mp->getFloor() << endl;
    if (health<0) health=0;
    cout << "HP: " << health << endl;
    cout << "Atk: " << atk+atkBonus << endl;
    cout << "Def: " << def+defBonus << endl;
}
