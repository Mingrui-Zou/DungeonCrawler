#include <string>
#include "vampire.h"
#include "player.h"
#include "map.h"
using namespace std;

Vampire::Vampire(int row, int col, Map *mp, Player *pc):
    NPC(row, col, mp, 'V', "Vampire", 50, 50, 25, 25, 1, true, pc) {}

Vampire::~Vampire() {}
