#include <iostream>
#include "map.h"
#include "displaymap.h"
using namespace std;

DisplayMap::DisplayMap(int h, int w): h(h), w(w) {
    display = new char*[h];
    for (int i=0; i<h; i++) display[i] = new char[w];
}

DisplayMap::~DisplayMap() {
    for (int i=0; i<h; i++) delete [] display[i];
    delete [] display;
}

void DisplayMap::notify(char sym, int r, int c) {
    display[r][c] = sym;
}

ostream& operator<<(ostream& out, const DisplayMap &mp) {
    for (int i=0; i<mp.h; i++) {
        for (int j=0; j<mp.w; j++) {
            out << mp.display[i][j];
        }
        out << endl;
    }

    return out;
}
