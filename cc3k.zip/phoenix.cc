#include <string>
#include "phoenix.h"
#include "player.h"
#include "map.h"
using namespace std;

Phoenix::Phoenix(int row, int col, Map *mp, Player *pc):
    NPC(row, col, mp, 'X', "Phoenix", 50, 50, 35,20, 1, true, pc) {}

Phoenix::~Phoenix() {}
