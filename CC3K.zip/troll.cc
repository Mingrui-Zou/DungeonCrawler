#include <string>
#include "troll.h"
#include "player.h"
#include "map.h"
using namespace std;

Troll::Troll(int row, int col, Map *mp, Player *pc):
    NPC(row, col, mp, 'T', "Troll", 120, 120, 25, 15, 1, true, pc) {}

Troll::~Troll() {}
