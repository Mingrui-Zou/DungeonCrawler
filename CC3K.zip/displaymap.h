#ifndef __DISPLAYMAP_H__
#define __DISPLAYMAP_H__
#include <iostream>

class Map;

class DisplayMap;

class DisplayMap {
    int h, w;
    char **display;

    public:
    DisplayMap(int h, int w);
    ~DisplayMap();

    void notify(char sym, int r, int c);

    friend std::ostream &operator<<(std::ostream &out, const DisplayMap &mp);
};

#endif
