#include <iostream>
#include <iomanip>
#include "map.h"
#include "cell.h"
#include "player.h"
#include "dwarf.h"
using namespace std;

Dwarf::Dwarf(int row, int col, Map *mp):
    Player(row, col, mp, 100, 100, 20, 30) {}

Dwarf::~Dwarf() {}


int Dwarf::takeTreasure(Cell *cll) {
    int amt = cll->getOccupant()->getVal();
    gold += 2*amt;
    addScore(2*amt);

    cll->clearOccupant(true);

    return amt;
}

string Dwarf::takePotion(Cell *cll) {
    string potName = cll->getOccupant()->use(this);
    cll->clearOccupant(true);
    return potName;
}

void Dwarf::playerInfo() {
    cout << setiosflags(ios::left);
    cout << "Race: Dwarf Gold: " << setw(WIDTH-26) << gold;
    cout << "Floor " << mp->getFloor() << endl;
    if (health<0) health=0;
    cout << "HP: " << health << endl;
    cout << "Atk: " << atk+atkBonus << endl;
    cout << "Def: " << def+defBonus << endl;
}
