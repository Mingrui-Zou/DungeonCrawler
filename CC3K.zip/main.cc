#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
#include <fstream>
#include "map.h"
#include "gameobject.h"
#include "character.h"
#include "player.h"
#include "human.h"
#include "elf.h"
#include "dwarf.h"
#include "ork.h"
#include "cell.h"
using namespace std;


int main(int argc, char *argv[]) {
    srand(1406223664);
    //cerr << time(NULL) << endl;fd
    bool done=false;
    while (!done) {
        
        ifstream floorList(argv[1]);
        string s;
        Map *mainMap;

        if (floorList>>s) { 
            ifstream floor1(s.c_str());
            mainMap = Map::getInstance();
            
            // player race selection input
            cout << "Select race: (h)uman (e)lf (d)warf (o)rk" << endl;
            while (cin>>s && s!="h" && s!="e" && s!="d" && s!="o") {
                cout << "Select race: (h)uman (e)lf (d)warf (o)rk" << endl;
            }
            
            // generates player race
            //initial position doesn't matter, position changes during generation
            Player *pc;
            if (s=="e") pc = new Elf(0, 0, mainMap);
            else if (s=="d") pc = new Dwarf(0, 0, mainMap);
            else if (s=="o") pc = new Ork(0, 0, mainMap);
            else pc = new Human(0, 0, mainMap); 

            mainMap->genMap(floor1,pc);
            cout << *mainMap;
            pc->playerInfo();
            mainMap->actionInfo();
            
            while (cin>>s && s!="q" && s!="r") {
                if (s=="a") {
                    if (cin>>s) {
                        pc->attackDir(s);
                    }
                } else {
                    if (!pc->action(s)) cerr << "you dummy" << endl;
                }

                if (mainMap->isNewFloor() && floorList>>s) {
                    mainMap->clearMap(false);
                    ifstream nextFloor(s.c_str());
                    mainMap->genMap(nextFloor,pc);
                } else if (mainMap->isNewFloor()) {
                    done = true;
                    cout << "Score: " << pc->getScore() << endl;
                    break;  //no more floors in floorList
                } else {    
                    mainMap->actionNPC();
                }
                
                cout << *mainMap;
                pc->playerInfo();
                mainMap->actionInfo();

                //checks if player dead
                if (pc->getHealth()<=0) {
                    cout << "(q)uit or (r)estart" << endl;
                    while (cin>>s && s!="q" && s!="r") {
                        cout << "(q)uit or (r)estart" << endl;
                    }
                    break;
                }
                

            }
            
            if (s=="q") {
                done=true;
            } else if (s=="r") {
                done=false;
            }
            
            cout << "Score: " << pc->getScore() << endl;
           
            mainMap->clearMap(true);
        
        } else {
            done=true;
        }
    }
    return 1;
}











